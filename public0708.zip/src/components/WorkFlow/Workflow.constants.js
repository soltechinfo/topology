export const initialNodes = [
    // {
    //   id: "1",
    //   type: "paymentInit",
    //   position: { x: 0, y: 0 },
    //   data: { amount: 10 },
    // },
    // {
    //   id: "2",
    //   type: "paymentCountry",
    //   position: { x: 200, y: 0 },
    //   data: { currency: "당산초등학교정문 CCTV", country: "192.168.255.255", countryCode: "US" },
    // },    
    // {
    //   id: "3",
    //   type: "paymentCountry",
    //   position: { x: 200, y: 150 },
    //   data: { currency: "￡", country: "England", countryCode: "GB" },
    // },  
    // {
    //   id: "4",
    //   type: "paymentProvider",
    //   position: { x: 550, y: -50 },
    //   data: { name: "102.168.025.255", code: "Gp" },
    // },           
    // {
    //   id: "5",
    //   type: "paymentProvider",
    //   position: { x: 550, y: 125 },
    //   data: { name: "Stripe", code: "St" },
    // },           
    // {
    //   id: "6",
    //   type: "paymentProvider",
    //   position: { x: 550, y: 325 },
    //   data: { name: "Apple Pay", code: "Ap" },
    // },           
    // {
    //   id: "7",
    //   type: "paymentProviderSelect",
    //   position: { x: 275, y: -100 },
    //   data: { },
    // },           
    // {
    //   id: "8",
    //   type: "input",
    //   position: { x: 0, y: -100 },
    //   data: { label: 'input node' },
    // },           
    // {
    //   id: "9",
    //   type: "circle",
    //   position: { x: 0, y: 100 },
    //   data: { label: 'input node' },
    // },   
  ];
  
export const initialEdges = [
    
];